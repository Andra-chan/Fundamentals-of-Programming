from domain.entities import Melodie
from repository.repo import RepoMelodie

class RepoFisierMelodie(RepoMelodie):
    """
    Responsabil cu stocarea melodiilor intr-un fisier
    Include:
    - citire din fisier
    - scriere in fisier
    - adaugare in fisier
    """
    
    
    def __init__(self,fileName):
        RepoMelodie.__init__(self)
        self.__fileName = fileName
        
    def __CreeazaMelodieDinFisier(self,fields):
        """
        Creeaza o melodie in fisier
        returneaza melodie
        """
        melodie = Melodie(fields[0],fields[1],fields[2],fields[3])
        return melodie 
    
    def __citesteDinFisier(self):
        """
        Citeste melodiile din fisier
        """
        f = open(self.__fileName,"r")
        self.__melodii = []
        line = f.readline().strip()
        while line != "":
            fields = line.split(",")
            melodie = self.__CreeazaMelodieDinFisier(fields)
            self.__melodii.append(melodie)
            line = f.readline().strip()
        f.close()
        
    def __scrieInFisier(self):
        """
        Scrie in fisier
        """
        f = open(self.__fileName,"w")
        melodii = RepoMelodie.getAllMelodii(self)
        for melodie in melodii:
            tot = melodie.get_titlu()+","+melodie.get_artist()+","+melodie.get_gen()+","+melodie.get_durata()
            f.write(tot+"\n")
        f.close
        
    def __adaugaInFisier(self, melodie):
        """Adauga pe ultima linie din fisier
        """
        f = open(self.__fileName,"a")
        tot = melodie.get_titlu()+","+melodie.get_artist()+","+melodie.get_gen()+","+melodie.get_durata()
        f.write(tot+"\n")
        f.close
        
    def store(self,melodie):
        """
        Stocheaza in fisier
        """
        RepoMelodie.store(self, melodie)
        self.__adaugaInFisier(melodie)
        
    def modificare_carte(self, titlu_vechi, artist_vechi, gen_vechi, durata_vechi, gen_nou, durata_nou):
        """
        Modifica din fisier
        """
        self.__citesteDinFisier()
        RepoMelodie.modificare_carte(self, titlu_vechi, artist_vechi, gen_vechi, durata_vechi, gen_nou, durata_nou)
        self.__scrieInFisier()
    
    