from domain.entities import Melodie

class RepositoryExceptie(Exception):
    pass

class RepoMelodie:
    def __init__(self):
        self.__melodii = []
    
    def store(self,melodie):
        """
        Stocheaza __melodii
        """
        self.__melodii.append(melodie)
        
    def size(self):
        """
        Numarul de melodii in repo
        returneaza un integru
        """
        return len(self.__melodii)
    
    def getAllMelodii(self):
        """
        returneaza o lista cu toate __melodii din repo
        """
        return self.__melodii[:]
    
    def modificare_carte(self,titlu_vechi,artist_vechi,gen_vechi,durata_vechi,gen_nou,durata_nou):
        """
        Modifica o melodie in functie de input-ul melodiei
        """
        for i in range(len(self.__melodii)):
            if self.__melodii[i].get_titlu() == titlu_vechi and self.__melodii[i].get_artist() == artist_vechi and self.__melodii[i].get_gen() == gen_vechi and self.__melodii[i].get_durata() == durata_vechi:
                self.__melodii[i].set_gen(gen_nou)
                self.__melodii[i].set_durata(durata_nou)
                return 
        raise RepositoryExceptie()
    
    def sort(self):
        for i in range(0,len(self.__melodii)-1):
            for j in range (i+1,len(self.__melodii)):
                if self.__melodii[i].get_artist()<self.__melodii[j].get_artist():
                    self.__melodii[i],self.__melodii[j]=self.__melodii[j],self.__melodii[i]
                if self.__melodii[i].get_titlu()<self.__melodii[j].get_titlu():
                    self.__melodii[i],self.__melodii[j]=self.__melodii[j],self.__melodii[i]               
    
def testRepoMelodie():
    repo = RepoMelodie()
    assert(repo.size() == 0)
    melodie = Melodie("Titlu1","Artist1","Rock","1")
    repo.store(melodie)
    assert(repo.size() == 1)
    try:
        repo.modificare_carte("Titlu1","Artist1","Jazz","1", "Pop", "5")
        assert(melodie == Melodie("Titlu1","Artist1","Pop","5"))
    except RepositoryExceptie:
        assert True
    
testRepoMelodie()   