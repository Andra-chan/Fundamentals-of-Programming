from domain.entities import Melodie

class ValidareExceptie(Exception):
    def __init__(self, errors):
        self.errors = errors
        
    def getErrors(self):
        return self.errors
    
class ValidatorMelodie:
    
    def valideaza(self,muzica):
        """
        Arunca ValidareExceptie daca fields nu sunt corecte
        """
        errors = []
        if muzica.get_titlu() == "" or muzica.get_titlu() == " ": errors.append("Field-ul Titlu nu poate sa fie gol!")
        if muzica.get_artist() == "" or muzica.get_artist() == " ": errors.append("Field-ul Artist nu poate sa fie gol!")
        if muzica.get_durata() == "" or muzica.get_durata() == " "or int(muzica.get_durata())<0:errors.append("Field-ul Durata nu este corect introdus!(nu poate fi gol si trebuie introdus un intreg pozitiv!")
        if muzica.get_gen() == "" or muzica.get_gen() == " ": errors.append("Field-ul Gen nu poate sa fie gol!")
        if muzica.get_gen() != "Rock" and muzica.get_gen() != "Pop" and muzica.get_gen() != "Jazz" and muzica.get_gen() != "Altele": errors.append("Genul trebuie sa fie: Rock, Pop, Jazz sau Altele!")
        if len(errors)>0:
            raise ValidareExceptie(errors)
        
        

def testValidatorMuzica():
    
    validator = ValidatorMelodie()
    
    muzica = Melodie("","","","")
    try:
        validator.valideaza(muzica)
        assert False
    except ValidareExceptie as ex:
        assert len(ex.getErrors()) == 5
        
    melodie = Melodie(" ", " ", " ", " ")
    try:
        validator.valideaza(melodie)
        assert False
    except ValidareExceptie as ex:
        assert len(ex.getErrors()) == 5
    
    melodie = Melodie("Titlu1", "", "", "")
    try:
        validator.valideaza(melodie)
        assert False
    except ValidareExceptie as ex:
        assert len(ex.getErrors()) == 4
        
    melodie = Melodie("Titlu1","Artist1","Pop","1")
    try:
        validator.valideaza(melodie)
        assert True
    except ValidareExceptie as ex:
        assert False
        
testValidatorMuzica()