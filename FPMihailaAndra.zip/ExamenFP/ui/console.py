from domain.validators import ValidareExceptie
from repository.repo import RepositoryExceptie
class Console:
    def __init__(self,srv):
        self.__srv = srv
        
    
    def __addMelodie(self):
        """
        functia care ia input-ul de la utilizator pentru a adauga o melodie
        """
        titlu = input("Titlul este: ")
        artist = input("Artistul este: ")
        gen = input("Genul Rock, Pop, Jazz sau Altele: ")
        durata = input("Durata in secunde este: ")
        try:
            melodie = self.__srv.CreeazaMelodie(titlu,artist,gen,durata)
            print("Melodia "+ melodie.get_titlu() + " a fost salvata...")
        except ValidareExceptie as ex:
            print(ex.getErrors())
            
    def __modificaMelodie(self): 
        """
        functia care ia input-ul de la utilizator pentru a modifica o melodie
        """     
        try:
            titlu_vechi= input("Introduceti titlul melodiei: ")  
            artist_vechi= input("Introduceti artistul melodiei: ") 
            gen_vechi= input("Introduceti genul melodiei: ") 
            durata_vechi= input("Introduceti durata melodiei: ")
            gen_nou = input("Introduceti genul nou: ") 
            durata_nou = input("Introduceti durata noua: ")
            self.__srv.modifica_carte(titlu_vechi,artist_vechi,gen_vechi,durata_vechi,gen_nou,durata_nou)
            print("Modificare realizata cu succes!")
        except RepositoryExceptie:
            print("Nu exista melodie cu aceste date!")
        except ValidareExceptie as ex:
            print(ex.getErrors())
            
    def __addMelodieRandom(self):
        """
        functia care ia input-ul de la utilizator pentru a adauga o melodie random
        """ 
        repetari = int(input("Cate melodii doriti sa adaugati? "))
        self.__srv.creeazaMelodieRandom(repetari)
        print("Adaugare realizata cu succes!")         

    def showUI(self):
        """
        meniul principal
        """
        meniu = True
        while meniu:
            print("""
1. Adauga melodie.
2. Modifica melodie.
3. Creeaza melodie aleatoriu.
4.Exporta melodie.
(exit pentru a iesi din aplicatie)
           """)
            cmd = input("Alegeti intre 1, 2 ,3 sau 4: ")
            if cmd == "1":
                self.__addMelodie()
            if cmd == "2":
                self.__modificaMelodie()
            if cmd == "3":
                self.__addMelodieRandom()
            if cmd == "exit":
                meniu = False           