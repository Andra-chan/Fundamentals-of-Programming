from random import randint,choice
import string

class Generare:
    """
    generator de melodii random
    genereaza string si integer pentru gen si durata
    """
    def __init__(self):
        pass
    
    def generare_numar(self):
        return randint(1,10000)
    
    def generare_string(self):
        litere = string.ascii_lowercase
        nume = "".join([choice(litere) for i in range(randint(3,10))])
        return nume