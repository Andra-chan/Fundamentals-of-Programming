from domain.validators import ValidatorMelodie
from service.serviceMelodii import ServiceMelodii
from ui.console import Console
from repository.repository_fisier import RepoFisierMelodie

repo = RepoFisierMelodie("melodii.txt")
val = ValidatorMelodie()
srv = ServiceMelodii(repo,val)
srv.CreeazaMelodie("Titlu1", "Artist1", "Rock", "100")
srv.CreeazaMelodie("Titlu2", "Artist2", "Rock", "150")
srv.CreeazaMelodie("Titlu3", "Artist3", "Jazz", "200")
srv.CreeazaMelodie("Titlu4", "Artist4", "Pop", "50")
srv.CreeazaMelodie("Titlu5", "Artist5", "Jazz", "400")
srv.CreeazaMelodie("Titlu6", "Artist6", "Altele", "600")
srv.CreeazaMelodie("Titlu7", "Artist7", "Pop", "75")
srv.CreeazaMelodie("Titlu8", "Artist8", "Pop", "136")
srv.CreeazaMelodie("Titlu9", "Artist9", "Altele", "270")
srv.CreeazaMelodie("Titlu10", "Artist10", "Rock", "189")
ui = Console(srv)

ui.showUI()