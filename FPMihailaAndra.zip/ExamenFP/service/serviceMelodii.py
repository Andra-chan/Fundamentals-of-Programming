from domain.entities import Melodie
from repository.repo import RepoMelodie
from domain.validators import ValidatorMelodie
from Generator.generare import Generare

class ServiceMelodii:
    def __init__(self,repo,val):
        """
        Initializeaza service
        repo - RepoMelodie (obiect ce stocheaza melodiile)
        val - validator (obiect ce valideaza melodiile)
        """
        self.__repo = repo
        self.__val = val
        
    def CreeazaMelodie(self,titlu, artist, gen, durata):
        """
        stocheaza o melodie
        titlu, artist, gen - string
        durata - integer
        returneaza melodie
        ridica ValidareExceptie daca field-urile sunt invalide
        """
        melodie = Melodie(titlu,artist,gen,durata)
        self.__val.valideaza(melodie)
        self.__repo.store(melodie)
        return melodie
        
    def getAllMelodii(self):
        """
        returneaza o lista cu toate melodiile
        """
        return self.__repo.getAllMelodii()
    
    def modifica_carte(self,titlu_vechi,artist_vechi,gen_vechi,durata_vechi,gen_nou,durata_nou):
        """
        face trimiterea catre repo pentru a realiza modificarea
        """
        self.__repo.modificare_carte(titlu_vechi,artist_vechi,gen_vechi,durata_vechi,gen_nou,durata_nou)
        
    def creeazaMelodieRandom(self,repetari):
        """
        functia care genereaza melodii random
        """
        gen = Generare()
        nr = 0
        while repetari>nr:
            titlu_random = gen.generare_string()
            artist_random = gen.generare_string()
            gen_random = gen.generare_string()
            durata_random = str(gen.generare_numar())
            melodie_random = Melodie(titlu_random,artist_random,gen_random,durata_random)
            self.__repo.store(melodie_random)
            nr+=1
                  
    
def testCreeazaMelodie():
    repo = RepoMelodie()
    val = ValidatorMelodie()
    srv = ServiceMelodii(repo,val)
    melodie = srv.CreeazaMelodie("Titlu1", "Artist1", "Rock", 1)
    assert melodie.get_titlu() == "Titlu1"
    assert melodie.get_artist() == "Artist1"
    assert melodie.get_gen() == "Rock"
    assert melodie.get_durata() == 1
    allMelodii = srv.getAllMelodii()
    assert len(allMelodii) == 1
    assert allMelodii[0] == melodie
    
testCreeazaMelodie()
    