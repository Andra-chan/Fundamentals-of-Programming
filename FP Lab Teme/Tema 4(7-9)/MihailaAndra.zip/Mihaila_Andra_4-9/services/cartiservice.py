from domain.entities import Carte
from repository.inmemory import InMemoryRepository
from repository.inmemory import RepositoryExceptie
from domain.validators import ValidatorCarte
from Generator.generator import Generare
'''from domain.datatransfer import AddressReportItem'''


class CarteService:
    def __init__(self,rep,val):
        """
        Initializeaza service
          Initialise service
          rep - reposirory - obiect ce stocheaza cartile
          val - validator - obiect ce valideaza cartile
        """
        self.__rep = rep
        self.__val = val

    def creeazaCarte(self,idct,titlu,descriere,autor):
        """
        stocheaza o carte
        idct, titlu, descriere, autor - string  
        returneaza Carte
        - adauga carte
        ridica RepositoryExceptie cartea exista deja
        ridica ValidationException - fieldurile de la carte sunt invalide
        """
        #creeaza obiectul carte
        ct = Carte(idct,titlu,descriere,autor)
        #validaeaza cartea folosit un obiect validator
        self.__val.valideaza(ct)
        #stocheaza cartea folosit repository
        self.__rep.store(ct)
        
        return ct
    
    def creeazaCarteRandom(self,repetari):
        gen = Generare()
        nr = 0
        while repetari>nr:
            id_ct = str(gen.generare_numar())
            titlu_ct = gen.generare_string()
            descriere_ct = gen.generare_string()
            autor_ct = gen.generare_string()
            carte_random = Carte(id_ct,titlu_ct,descriere_ct,autor_ct)
            try:
                self.__rep.store(carte_random)
                nr += 1
            except RepositoryExceptie():
                continue

    
    def getAllCarti(self):
        """
        returneaza o lista cu toate cartile
        """
        return self.__rep.getAllCarti()
    
    def sterge_carte_si_inchiriere_id(self,idct):
        self.__rep.sterge_carte_id(idct)
     
    """   
    def modif_carte_id(self,id_vechi,id_modif):
        self.__rep.modifica_carte_id(id_vechi,id_modif)
    """
        
    def modif_carte_titlu(self,titlu_vechi,titlu_modif):
        self.__rep.modifica_carte_titlu(titlu_vechi,titlu_modif)
        
    def modif_carte_descriere(self,descriere_vechi,descriere_modif):
        self.__rep.modifica_carte_descriere(descriere_vechi,descriere_modif)
        
    def modif_carte_autor(self,autor_vechi,autor_modif):
        self.__rep.modifica_carte_autor(autor_vechi,autor_modif)
        
    def cauta_carte_id(self,id_carte):
        self.__rep.cautare_carte_id(id_carte)

def testCreeazaCarte():
    rep = InMemoryRepository()
    val = ValidatorCarte()
    srv = CarteService(rep,val)
    ct = srv.creeazaCarte("1","Titlu","Descriere","Autor")
    assert ct.getId()=="1"
    assert ct.getTitlu()=="Titlu"
    assert ct.getDescriere()=="Descriere"
    assert ct.getAutor()=="Autor"
    allCrt = srv.getAllCarti()
    assert len(allCrt)==1
    assert allCrt[0]== ct
    
    try:
        ct = srv.creeazaCarte("1","Carte","Descriere","Titlu")
        assert False
    except RepositoryExceptie:
        assert True

testCreeazaCarte()
