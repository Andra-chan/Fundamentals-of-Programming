from domain.entities import Client
from repository.inmemory import InMemoryRepositoryClient
from repository.inmemory import RepositoryExceptie
from domain.validators import ValidatorClient
from Generator.generator import Generare
'''from domain.datatransfer import AddressReportItem'''


class ClientService:
    def __init__(self,repcl,valcl):
        """
        Initializeaza service
          Initialise service
          repcl - reposirory - obiect ce stocheaza clientii
          valcl - validator - obiect ce valideaza clientii
        """
        self.__rep = repcl
        self.__val = valcl

    def creeazaClient(self,idcl,nume,cnp):
        """
        stocheaza un client
        idcl, nume, cnp - string  
        returneaza Client
        - adauga client
        ridica RepositoryExceptie clientul exista deja
        ridica ValidationException - fieldurile de la client sunt invalide
        """
        #creeaza obiectul client
        cl = Client(idcl,nume,cnp)
        #validaeaza clientul folosit un obiect validator
        self.__val.valideazaClient(cl)
        #stocheaza clientul folosit repository
        self.__rep.storeClient(cl)
        
        return cl
    
    def creeazaClientRandom(self,repetari_client):
        gen = Generare()
        nr = 0
        while repetari_client>nr:
            id_cl = str(gen.generare_numar())
            nume_ct = gen.generare_string()
            cnp_ct = str(gen.generare_numar())
            client_random = Client(id_cl,nume_ct,cnp_ct)
            try:
                self.__rep.storeClient(client_random)
                nr += 1
            except RepositoryExceptie():
                continue

    
    def getAllClienti(self):
        """
        returneaza o lista cu toti Clientii
        """
        return self.__rep.getAllClienti()

    def sterge_client_cnp(self,cnp):
        self.__rep.stergere_client_cnp(cnp)
        
    def modif_client_id(self,idcl_vechi,idcl_modif):
        self.__rep.modifica_client_id(idcl_vechi,idcl_modif)
    
    def modif_client_nume(self,nume_vechi,nume_modif):
        self.__rep.modifica_client_nume(nume_vechi,nume_modif)
        
    def cauta_client_cnp(self,cnp_client):
        self.__rep.cautare_client_cnp(cnp_client)

def testCreeazaClienti():
    repcl = InMemoryRepositoryClient()
    valcl = ValidatorClient()
    srvcl = ClientService(repcl,valcl)
    cl = srvcl.creeazaClient("1","Nume1","cnp1")
    assert cl.getIdcl()=="1"
    assert cl.getNume()=="Nume1"
    assert cl.getCNP()=="cnp1"
    allCl = srvcl.getAllClienti()
    assert len(allCl)==1
    assert allCl[0]== cl
    
    try:
        cl = srvcl.creeazaClient("1","Nume","cnp1")
        assert False
    except RepositoryExceptie:
        assert True

testCreeazaClienti()