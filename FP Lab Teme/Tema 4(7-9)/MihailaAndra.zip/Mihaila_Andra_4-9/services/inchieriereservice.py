from domain.entities import Inchiriere,InchiriereDTO
from repository.inmemory import InMemoryRepositoryInchiriere,InMemoryRepository,InMemoryRepositoryClient
from repository.inmemory import RepositoryExceptie
from domain.validators import ValidatorInchiriere, ValidatorCarte,ValidatorClient
from services.cartiservice import CarteService
from services.clientiservice import ClientService

class InchiriereService:
    
    def __init__(self, valinch, repinch, rep, repcl):
        self.__valinch = valinch
        self.__repinch = repinch
        self.__rep = rep
        self.__repcl = repcl
        
    def creeazaInchiriere(self,id_inch,idct,idcl):
        carte = self.__rep.getCartebyId(idct)
        client = self.__repcl.getClientbyId(idcl)
        inchiriere = Inchiriere(id_inch,carte,client)
        self.__valinch.valideazaInchiriere(inchiriere)
        self.__repinch.store(inchiriere)
        
    def getAllInchirieri(self):
        inchirieri = self.__repinch.getAllInchirieri()
        inchirieri_dtos = []
        for inchiriere in inchirieri:
            id_inch = inchiriere.get_id_inch()
            nume_carte = self.__rep.getCartebyId(inchiriere.get_carte().getId()).getTitlu()
            nume_client = self.__repcl.getClientbyId(inchiriere.get_client().getIdcl()).getNume()
            inchiriere_dto = InchiriereDTO(id_inch,nume_carte,nume_client)
            inchirieri_dtos.append(inchiriere_dto)
        return inchirieri_dtos
    
    def stergere_inch_id(self,idct):
        inchirieri = self.__repinch.getAllInchirieri()
        for inchiriere in inchirieri:
            if inchiriere.get_carte().getId() == idct:
                self.__repinch.sterge_inchiriere_id(inchiriere.get_id_inch())
                
    def stergere_inch_cnp(self,cnp):
        inchirieri = self.__repinch.getAllInchirieri()
        for inchiriere in inchirieri:
            if inchiriere.get_client().getCNP() == cnp:
                self.__repinch.sterge_inchiriere_id(inchiriere.get_id_inch())
                
    def top_inchirieri(self):
        self.__repinch.view_top_inchirieri()

    def top_clienti(self):
        self.__repinch.view_top_clienti()
        
    def top_20_clienti(self):
        self.__repinch.view_top_20_clienti()
        
    def top_autori(self):
        self.__repinch.view_top_autori()

def testCreeazaInchirieri():
    repinch = InMemoryRepositoryInchiriere()
    valinch = ValidatorInchiriere()
    rep = InMemoryRepository()
    val = ValidatorCarte()
    repcl = InMemoryRepositoryClient()  
    valcl = ValidatorClient()
    srvinch = InchiriereService(valinch,repinch,rep,repcl)
    ctr = CarteService(rep,val)
    ctr.creeazaCarte("1","Ion","Pamant","Liviu Rebreanu")
    clr = ClientService(repcl,valcl)
    clr.creeazaClient("2","Andra","cnp1")
    srvinch.creeazaInchiriere("1","1","2")
    inchiriere = Inchiriere("1","1","2")
    assert inchiriere.get_id_inch() == "1"
    assert inchiriere.get_carte() == "1"
    assert inchiriere.get_client() == "2"
    
    try:
        inchiriere = srvinch.creeazaInchiriere("1","2","3")
        assert False
    except RepositoryExceptie:
        assert True

testCreeazaInchirieri()