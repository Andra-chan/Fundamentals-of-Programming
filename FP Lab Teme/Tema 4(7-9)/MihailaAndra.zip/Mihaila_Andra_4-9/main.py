#from repository.inmemory import InMemoryRepository
from services.cartiservice import CarteService
from ui.console import Console
from domain.validators import ValidatorCarte, ValidatorClient, ValidatorInchiriere
from repository.filerepository import CarteRepositoryFile, ClientRepositoryFile, InchiriereRepositoryFile
from services.clientiservice import ClientService
from services.inchieriereservice import InchiriereService
# from repository.filerepo import StudentRepositoryFile


# rep = InMemoryRepository()
rep = CarteRepositoryFile("carti.txt")
repcl = ClientRepositoryFile("clienti.txt")
repinch = InchiriereRepositoryFile("inchirieri.txt")
val = ValidatorCarte()
valcl = ValidatorClient()
valinch = ValidatorInchiriere()
ctr = CarteService(rep,val)
ctr.creeazaCarte("1","Ion","Pamant","Liviu Rebreanu")
ctr.creeazaCarte("2","Povestea lui Harap-ALb","Rau vs Bine","Ion Creanga")
ctr.creeazaCarte("3","Enigma Otiliei","Otilia si Felix","George Calinescu")
ctr.creeazaCarte("4","Amitiri din copilarie","Amintiri","Ion Creanga")
clr = ClientService(repcl,valcl)
clr.creeazaClient("1","Andra","cnp1")
clr.creeazaClient("2","Mihaela","cnp2")
clr.creeazaClient("3","Petre","cnp3")
srvinch = InchiriereService(valinch, repinch, rep, repcl)
srvinch.creeazaInchiriere("1","1","2")
srvinch.creeazaInchiriere("2","2","3")
srvinch.creeazaInchiriere("3","3","1")
srvinch.creeazaInchiriere("4","4","1")
srvinch.creeazaInchiriere("5","2","1")
ui = Console(ctr,clr,srvinch)

ui.showUI()
