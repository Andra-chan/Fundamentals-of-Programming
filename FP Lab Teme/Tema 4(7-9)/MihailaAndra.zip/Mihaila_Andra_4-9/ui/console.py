from repository.inmemory import RepositoryExceptie
from domain.validators import ValidareExceptie

class Console:
    def __init__(self, srv, srvcl, srvinch):
        self.__srv = srv
        self.__srvcl = srvcl
        self.__srvinch = srvinch

    def __showAllCarti(self):
        """
        Da print la toate cartile din biblioteca
        """
        cti = self.__srv.getAllCarti()
        if len(cti) == 0:
            print("Nu avem carti in biblioteca!")
        else:
            print("Id        Titlu        Descriere        Autor")
        for ct in cti:
            print(ct.getId(), ct.getTitlu(), ct.getDescriere(), ct.getAutor())
    
    def __showAllClienti(self):
        """
        Da print la toti clientii bibliotecii
        """
        cli = self.__srvcl.getAllClienti()
        if len(cli) == 0:
            print("Nu avem clienti!")
        else:
            print("Id        Nume        CNP")
        for cl in cli:
            print(cl.getIdcl(), cl.getNume(), cl.getCNP())
            
    def __showAllInchirieri(self):
        """
        Da print la toate inchirierile cartilor
        """
        inc = self.__srvinch.getAllInchirieri()
        if len(inc) == 0:
            print("Nu avem carti inchiriate!")
        else:
            print("Id        Titlu    ->    Client")
        for inchiriere in inc:
            print(inchiriere)
    
    
    def __topInchirieri(self):
        self.__srvinch.top_inchirieri()
        
    def __topClienti(self):
        self.__srvinch.top_clienti()
        
    def __top20Clienti(self):
        self.__srvinch.top_20_clienti()
        
    def __topAutori(self):
        self.__srvinch.top_autori()
  
            
    def __addCarte(self):
        """
        Adauga Carte din consola
        """
        idCt = input("ID-ul este: ")
        titlu = input("Titlul este: ")
        descriere = input("Descrierea este: ")
        autor = input("Autorul este: ")
        try:
            ct = self.__srv.creeazaCarte(idCt, titlu, descriere, autor)
            print("Cartea " + ct.getTitlu() + " a fost salvata...")
        except RepositoryExceptie:
            print("Exista deja o carte cu acelasi ID")
        except ValidareExceptie as ex:
            print(ex.getErrors())      
           
    def __addClient(self):
        """
        Adauga Client din consola
        """
        idCl = input("ID-ul este: ")
        nume = input("Numele este:")
        cnp = input("CNP-ul este: ")
        try:
            cl = self.__srvcl.creeazaClient(idCl, nume, cnp)
            print("Clientul " + cl.getNume() + " a fost salvat(a)...")
        except RepositoryExceptie:
            print("Exista deja un client cu acelasi CNP")
        except ValidareExceptie as ex:
            print(ex.getErrors())
            
    def __addInchirieri(self):
        id_inch = input("Introduceti ID-ul inchirierii: ")
        idct = input("Introduceti ID-ul cartii: ")
        idcl = input("Introduceti ID-ul clientului: ")
        try:
            inchiriere = self.__srvinch.creeazaInchiriere(id_inch,idct,idcl)
            print("Inchirierea a fost realizata!")
        except RepositoryExceptie:
            print("Exista deja o inchiriere cu acelasi ID")
        except ValidareExceptie as ex:
            print(ex.getErrors()) 
  
        
    def __stergeCarteId(self):
        try:
            idct = input("Cartea cu ce ID doriti sa stergeti? ")
            self.__srv.sterge_carte_si_inchiriere_id(idct)
            self.__srvinch.stergere_inch_id(idct)
            print("Stergere realizata cu succes!")
        except RepositoryExceptie:
            print("Nu exista carte cu acel ID!")
        except ValidareExceptie as ex:
            print(ex.getErrors())

    def __stergeClientCNP(self):
        try:
            cnp = input("Clientul cu ce CNP doriti sa stergeti? ")
            self.__srvcl.sterge_client_cnp(cnp)
            self.__srvinch.stergere_inch_cnp(cnp)
            print("Stergere realizata cu succes!")
        except RepositoryExceptie:
            print("Nu exista client cu acel CNP!")
        except ValidareExceptie as ex:
            print(ex.getErrors())
            
    def __stergeInchiriereId(self):
        try:
            idct = input("Inchirierea cu ce ID doriti sa stergeti? ")
            self.__srvinch.stergere_inch_id(idct)           
            print("Stergere realizata cu succes!")
        except RepositoryExceptie:
            print("Nu exista inchiriere cu acel ID!")
        except ValidareExceptie as ex:
            print(ex.getErrors())
    
    """
    def __modificaCarteId(self):
        try:
            id_vechi = input("Introduceti ID-ul vechi: ")
            id_modif = input("Introduceti noul ID: ")
            self.__srv.modif_carte_id(id_vechi,id_modif)
            print("Modificare realizata cu succes!")
        except RepositoryExceptie:
            print("Nu exista carte cu acel ID!")
        except ValidareExceptie as ex:
            print(ex.getErrors())
    """
        
    def __modificaCarteTitlu(self):
        try:
            titlu_vechi = input("Introduceti Titlul vechi: ")
            titlu_modif = input("Introduceti noul Titlu: ")
            self.__srv.modif_carte_titlu(titlu_vechi,titlu_modif)
            print("Modificare realizata cu succes!")
        except RepositoryExceptie:
            print("Nu exista carte cu acel Titlu!")
        except ValidareExceptie as ex:
            print(ex.getErrors())

    def __modificaCarteDescriere(self):
        try:
            descriere_vechi = input("Introduceti Descrierea veche: ")
            descriere_modif = input("Introduceti noua Descriere: ")
            self.__srv.modif_carte_descriere(descriere_vechi,descriere_modif)  
            print("Modificare realizata cu succes!")  
        except RepositoryExceptie:
            print("Nu exista carte cu acea Descriere!")
        except ValidareExceptie as ex:
            print(ex.getErrors())
            
    def __modificaCarteAutor(self):
        try:
            autor_vechi = input("Introduceti Autorul vechi: ")
            autor_modif = input("Introduceti noul Autor: ")
            self.__srv.modif_carte_autor(autor_vechi,autor_modif)
            print("Modificare realizata cu succes!")
        except RepositoryExceptie:
            print("Nu exista carte  cu acel Autor!")
        except ValidareExceptie as ex:
            print(ex.getErrors())
    
    def __modificaClientId(self):
        try:
            idcl_vechi = input("Introduceti ID-ul vechi: ")
            idcl_modif = input("Introduceti noul ID: ")
            self.__srvcl.modif_client_id(idcl_vechi,idcl_modif)
            print("Modificare realizata cu succes!")
        except RepositoryExceptie:
            print("Nu exista client cu acel ID!")
        except ValidareExceptie as ex:
            print(ex.getErrors())
    
    def __modificaClientNume(self):
        try:
            nume_vechi = input("Introduceti Numele vechi: ")
            nume_modif = input("Introduceti noul Nume: ")
            self.__srvcl.modif_client_nume(nume_vechi,nume_modif)
            print("Modificare realizata cu succes!")
        except RepositoryExceptie:
            print("Nu exista client cu acel Nume!")
        except ValidareExceptie as ex:
            print(ex.getErrors())  
 
    
    def __cautaCarteId(self):
        try:
            id_carte = input("Introduceti ID-ul cartii cautate: ")
            self.__srv.cauta_carte_id(id_carte)
        except RepositoryExceptie:
            print("Nu exista carte cu acel ID!")
        except ValidareExceptie as ex:
            print(ex.getErrors())
        
    def __cautaClientCNP(self):
        try:
            cnp_client = input("Introduceti CNP-ul clientului cautat: ")
            self.__srvcl.cauta_client_cnp(cnp_client)
        except RepositoryExceptie:
            print("Nu exista client cu acel CNP!")
        except ValidareExceptie as ex:
            print(ex.getErrors())
  
          
    def __addCarteRandom(self):
        repetari = int(input("Cate carti doriti sa adaugati? "))
        self.__srv.creeazaCarteRandom(repetari)
        
    def __addClientRandom(self):
        repetari_client = int(input("Cati clienti doriti sa adaugati? "))
        self.__srvcl.creeazaClientRandom(repetari_client)
        
    def showUI(self):
        while True:
            print("Informatii suplimentare: cartile nu pot avea acelasi 'ID', clientii nu pot avea acelasi CNP!")
            cmd = input("""1. Pentru a adauga o carte, inserati add carte.
2. Pentru a vizualiza lista de carti, inserati view carti.
3. Pentru a inregistra un client, inserati add client.
4. Pentru a vizualiza lista clientilor, inserati view clienti.
5. Pentru a adauga o inchiriere, inserati add inchirieri.
6. Pentru a sterge o inchiriere(returnare) dupa ID, inserati sterge inchiriere id.
7. Pentru a vedea toate inchirierile, inserati view inchirieri.
8. Pentru a sterge o carte dupa ID, inserati sterge carte id.
9. Pentru a sterge un client dupa CNP, inserati sterge client cnp.
10. Pentru a modifica Titlul unei carti, inserati modifica carte titlu.
11. Pentru a modifica Descrierea unei carti, inserati modifica carte descriere.
12. Pentru a modifica Autorul unei carti, inserati modifica carte autor.
13. Pentru a modifica ID-ul unui client, inserati modifica client id.
14. Pentru a modifica numele unui client, inserati modifica client nume.
15. Pentru a cauta o carte dupa ID, inserati cauta carte id.
16. Pentru a cauta un client dupa CNP, inserati cauta client cnp.
17. Pentru a vedea cele mai inchiriate carti, inserati top inchirieri.
18. Pentru a vedea cei mai activi clienti, inserati top clienti.
19. Pentru a vedea primi 20% dintre cei mai activi clienti, inserati top 20 clienti.
20. Pentru a iesi din aplicatie, inserati exit.
1*. Pentru a adauga carti random, inserati add carte random.
2*. Pentru a adauga clienti random, inserati add client random.
3*. Pentru a vedea autorii preferati, inserati top autori.
Comanda dumneavoastra: """)
            if cmd == "add carte":
                self.__addCarte()
            if cmd == "view carti":
                self.__showAllCarti()
            if cmd == "add client":
                self.__addClient()
            if cmd == "view clienti":
                self.__showAllClienti()
            if cmd == "add inchiriere":
                self.__addInchirieri()
            if cmd == "sterge inchiriere id":
                self.__stergeInchiriereId()
            if cmd == "view inchirieri":
                self.__showAllInchirieri()  
            if cmd == "sterge carte id":
                self.__stergeCarteId()
            if cmd == "sterge client cnp":
                self.__stergeClientCNP()
            if cmd == "modifica carte titlu":
                self.__modificaCarteTitlu()
            if cmd == "modifica carte descriere":
                self.__modificaCarteDescriere()  
            if cmd == "modifica carte autor":
                self.__modificaCarteAutor()
            if cmd == "modifica client id":
                self.__modificaClientId()
            if cmd == "modifica client nume":
                self.__modificaClientNume()
            if cmd == "cauta carte id":
                self.__cautaCarteId()
            if cmd == "cauta client cnp":
                self.__cautaClientCNP()
            if cmd == "top inchirieri":
                self.__topInchirieri()
            if cmd == "top clienti":
                self.__topClienti()
            if cmd == "top 20 clienti":
                self.__top20Clienti()
            if cmd == "add carte random":
                self.__addCarteRandom()
            if cmd == "add client random":
                self.__addClientRandom()
            if cmd == "top autori":
                self.__topAutori()
            if cmd == "exit":
                print("La revedere!")
                return