class Carte:
    def __init__(self,idct, titlu, descriere, autor):
        """
        Creeaza o carte cu idct, titlu, descriere, autor de tip string
        """
        self.__id = idct
        self.__titlu = titlu
        self.__descriere = descriere
        self.__autor = autor

    """
    def set_id(self, value):
        self.__id = value
    """

    def set_titlu(self, value):
        self.__titlu = value


    def set_descriere(self, value):
        self.__descriere = value


    def set_autor(self, value):
        self.__autor = value

        
    def getId(self):
        return self.__id
    
    def getTitlu(self):
        return self.__titlu
    
    def getDescriere(self):
        return self.__descriere
    
    def getAutor(self):
        return self.__autor
    
    def __eq__(self,ct):
        """
        Verifica egalitatea dintre doua carti.
        ct - carte
        returneaza True daca cartea curenta este egala cu ct (adica au acelasi id)
        """
        return self.getId()==ct.getId()
    
    
class Client:
    def __init__(self,idcl, nume, cnp):
        """
        Creeaza un client cu idcl, nume, cnp
        """
        self.__idcl = idcl
        self.__nume = nume
        self.__cnp = cnp

    def set_idcl(self, value):
        self.__idcl = value

    def set_nume(self, value):
        self.__nume = value
        
    def getIdcl(self):
        return self.__idcl
    
    def getNume(self):
        return self.__nume
    
    def getCNP(self):
        return self.__cnp
    
    def __eq__(self,cl):
        """Verifica egalitatea dintre doi clienti
        cl - client
        returneaza True daca clientul curent este acelasi cu cl(adica au acelasi cnp)
        """
        return self.getCNP() == cl.getCNP()


class Inchiriere():  
    def __init__(self,id_inch,carte,client):
        self.__id_inch = id_inch
        self.__carte = carte
        self.__client = client

    def get_id_inch(self):
        return self.__id_inch


    def get_carte(self):
        return self.__carte


    def get_client(self):
        return self.__client
    
    def __eq__(self,inchiriere):
        return self.get_id_inch() == inchiriere.get_id_inch()


def testCreeazaCarte():
    """
    Testeaza crearea cartilor
    """
    ct = Carte("1", "Harap-Alb", "Rau vs Bine", "Ion Creanga")
    assert ct.getId() == "1"
    assert ct.getTitlu() == "Harap-Alb"
    assert ct.getDescriere() == "Rau vs Bine"
    assert ct.getAutor() == "Ion Creanga"
def testEgal():
    """
    Testeaza egalitatea dintre doua carti
    """
    ct1 = Carte("1", "Harap-Alb", "Rau vs Bine", "Ion Creanga")
    ct2 = Carte("1", "Harap-Alb", "Rau vs Bine", "Ion Creanga")
    assert ct1 == ct2
    
testCreeazaCarte()
testEgal()

def testCreeazaClient():
    """
    Testeaza crearea clientilor
    """
    cl = Client("1","Ana","cnp1")
    assert cl.getIdcl() == "1"
    assert cl.getNume() == "Ana"
    assert cl.getCNP() == "cnp1"
def testEgalitate():
    """
    Testeaza egalitatea dintre doi clienti
    """
    cl1 = Client("1","Ana","cnp1")
    cl2 = Client("1","Ana","cnp1")
    assert cl1 == cl2
 
testCreeazaClient()   
testEgalitate()

def testCreeazaInchiriere():
    """
    Testeaza crearea inchirierilor
    """
    inchiriere = Inchiriere("1","Ion","Ana")
    assert inchiriere.get_id_inch() == "1"
    assert inchiriere.get_carte() == "Ion"
    assert inchiriere.get_client() == "Ana"   
def testEglitateInchiriere():
    """
    Testeaza egalitatea dintre doua inchirieri
    """
    inchiriere1 = Inchiriere("1","Ion","Ana")
    inchiriere2 = Inchiriere("1","Ion","Ana")
    assert inchiriere1 == inchiriere2
    
testCreeazaInchiriere()
testEglitateInchiriere()


class InchiriereDTO:
    
    
    def __init__(self, id_inch, nume_carte, nume_client):
        self.__id_inch = id_inch
        self.__nume_carte = nume_carte
        self.__nume_client = nume_client
    
    def __str__(self):
        return str(self.__id_inch)+" "+self.__nume_carte+"->"+self.__nume_client