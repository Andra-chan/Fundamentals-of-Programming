from domain.entities import Carte
from domain.entities import Client
from domain.entities import Inchiriere

class ValidareExceptie(Exception):
    def __init__(self, errors):
        self.errors=errors
        
    def getErrors(self):
        return self.errors
    
class ValidatorCarte:
    
    def valideaza(self, ct):
        """
        Arunca ValidareExceptie daca fields sunt goale
        """
        errors = [] 
        if (ct.getId()=="" or ct.getId()==" " or int(ct.getId())<0): errors.append("Field-ul 'ID' nu poate sa fie gol!")
        if (ct.getTitlu()=="" or ct.getTitlu()==" "): errors.append("Field-ul 'Titlu' nu poate sa fie gol!")
        if (ct.getDescriere()=="" or ct.getDescriere()==" "): errors.append("Field-ul 'Descriere' nu poate sa fie goal!")
        if (ct.getAutor()=="" or ct.getAutor()==" "): errors.append("Field-ul 'Autor' nu poate sa fie gol!")
        if len(errors)>0:
            raise ValidareExceptie(errors)
        
class ValidatorClient:
    
    def valideazaClient(self, cl):
        """
        Arunca ValidareExceptie daca fields sunt goale
        """
        errors = []
        if(cl.getIdcl()=="" or cl.getIdcl()==" "): errors.append("Id-ul nu poate sa fie gol!")
        if(cl.getNume()=="" or cl.getNume()==" "): errors.append("Numele nu poate sa fie gol!")
        if(cl.getCNP()=="" or cl.getCNP()==" "): errors.append("CNP-ul nu poate sa fie gol!")
        if len(errors)>0:
            raise ValidareExceptie(errors)
        
def testValidatorClient():
    """
    testeza validarea clientilor
    """
    validator = ValidatorClient()      
    
    cl = Client("", "", "") 
    try:
        validator.valideazaClient(cl)
        assert False
    except ValidareExceptie as ex:
        assert len(ex.getErrors()) == 3
    
    cl = Client(" ", " ", " ") 
    try:
        validator.valideazaClient(cl)
        assert False
    except ValidareExceptie as ex:
        assert len(ex.getErrors()) == 3
        
    cl = Client("5467", "", "")
    try:
        validator.valideazaClient(cl)
        assert False
    except ValidareExceptie as ex:
        assert len(ex.getErrors()) == 2
        
    cl = Client("1", "Ana", "cnp1")
    try:
        validator.valideazaClient(cl)
        assert True
    except ValidareExceptie as ex:
        assert False   
        
testValidatorClient()  

def testValidatorCarte():
    """
    testeza validarea cartilor
    """
    validator = ValidatorCarte()
    
    ct = Carte("", "", "", "")
    try:
        validator.valideaza(ct)
        assert False
    except ValidareExceptie as ex:
        assert len(ex.getErrors()) == 4
        
    ct = Carte(" ", " ", " ", " ")
    try:
        validator.valideaza(ct)
        assert False
    except ValidareExceptie as ex:
        assert len(ex.getErrors()) == 4
    
    ct = Carte("5467", "", "", "")
    try:
        validator.valideaza(ct)
        assert False
    except ValidareExceptie as ex:
        assert len(ex.getErrors()) == 3
        
    ct = Carte("1", "Harap-Alb", "Rau vs Bine", "Ion Creanga")
    try:
        validator.valideaza(ct)
        assert True
    except ValidareExceptie as ex:
        assert False

testValidatorCarte()

class ValidatorInchiriere:
    def __init__(self):
        pass
    
    def valideazaInchiriere(self,inchiriere):
        errors = []
        if (inchiriere.get_id_inch()=="" or inchiriere.get_id_inch()==" "): errors.append("ID invalid!")
        if len(errors)>0:
            raise ValidareExceptie(errors)
        
def testValidatorInchiriere():
    """
    testeza validarea inchirierilor
    """
    validator = ValidatorInchiriere()
    
    inchiriere = Inchiriere("","","")
    try:
        validator.valideazaInchiriere(inchiriere)
        assert False
    except ValidareExceptie as ex:
        assert len(ex.getErrors()) == 1
        
    inchiriere = Inchiriere(" "," "," ")
    try:
        validator.valideazaInchiriere(inchiriere)
        assert False
    except ValidareExceptie as ex:
        assert len(ex.getErrors()) == 1
        
    inchiriere = Inchiriere("1","Ion","Andra")
    try:
        validator.valideazaInchiriere(inchiriere)
        assert True
    except ValidareExceptie as ex:
        assert False
        
testValidatorInchiriere()