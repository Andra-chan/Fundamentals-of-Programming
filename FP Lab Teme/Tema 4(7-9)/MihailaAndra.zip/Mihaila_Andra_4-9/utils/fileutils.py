def clearFileContent(fileName):
    """
    Sterge continutul unui file(file va exista si va fi goala)
    """
    f = open(fileName, "w")
    f.close()