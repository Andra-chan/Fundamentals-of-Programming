from domain.entities import Carte, Inchiriere
from domain.entities import Client


class RepositoryExceptie(Exception):
    pass

class InMemoryRepository:
    def __init__(self):
        self.__carti = []
        
    def store(self,ct):
        """
        Stocheaza ___carti
        ct e o carte
        ridica RepositoryExceptie daca avem o carte cu acelasi id
        """
        if ct in self.__carti:
            raise RepositoryExceptie()
        self.__carti.append(ct)
        
    def size(self):
        """
        Numarul de __carti in repository
        returneaza un integru
        """
        return len(self.__carti)

    def getAllCarti(self):
        """
        returneaza o lista, lista cu toti __carti in repository
        """
        return self.__carti[:]
    
    def getAllIdCarti(self):
        return self.__carti.getId()[:]
    
    def getCartebyId(self,idct):
        for ct in self.__carti:
            if ct.getId()==idct:
                return ct
        raise RepositoryExceptie("Element inexistent!")
    
    def sterge_carte_id(self,idct):
        for i in range(len(self.__carti)):
            if self.__carti[i].getId() == idct:
                del self.__carti[i]
                return
        raise RepositoryExceptie()

    """   
    def modifica_carte_id(self,id_vechi,id_modif):
        for i in range(len(self.__carti)):
            if self.__carti[i].getId() == id_vechi:
                self.__carti[i].set_id(id_modif)
                return
        raise RepositoryExceptie()
    """
        
    def modifica_carte_titlu(self,titlu_vechi,titlu_modif):
        for i in range(len(self.__carti)):
            if self.__carti[i].getTitlu() == titlu_vechi:
                self.__carti[i].set_titlu(titlu_modif)
                return
        raise RepositoryExceptie()
        
    def modifica_carte_descriere(self,descriere_vechi,descriere_modif):
        for i in range(len(self.__carti)):
            if self.__carti[i].getDescriere() == descriere_vechi:
                self.__carti[i].set_descriere(descriere_modif)
                return
        raise RepositoryExceptie()
        
    def modifica_carte_autor(self,autor_vechi,autor_modif):
        for i in range(len(self.__carti)):
            if self.__carti[i].getAutor() == autor_vechi:
                self.__carti[i].set_autor(autor_modif)
                return
        raise RepositoryExceptie()
        
    def cautare_carte_id(self,id_carte):
        for i in range(len(self.__carti)):
            if self.__carti[i].getId() == id_carte:
                cautare = self.__carti[i].getId()+"   "+self.__carti[i].getTitlu()+"   "+self.__carti[i].getDescriere()+"   "+self.__carti[i].getAutor()
                print(cautare)
                return
        raise RepositoryExceptie()
        
class InMemoryRepositoryClient:
    def __init__(self):
        self.__clienti = []
        
    def storeClient(self,cl):
        """
        Stocheaza ___clienti
        cl e un client
        ridica RepositoryExceptie daca avem un client cu acelasi CNP
        """
        if cl in self.__clienti:
            raise RepositoryExceptie()
        self.__clienti.append(cl)
        
    def size(self):
        """
        Numarul de __clienti in repository
        returneaza un integru
        """
        return len(self.__clienti)
    
    def getAllClienti(self):
        """
        returneaza o lista, lista cu toti __clienti in repository
        """
        return self.__clienti[:]
    
    def getClientbyId(self,cnp):
        for cl in self.__clienti:
            if cl.getIdcl()==cnp:
                return cl
        raise RepositoryExceptie("Element inexistent!")
    
    def stergere_client_cnp(self,cnp):
        for i in range(len(self.__clienti)):
            if self.__clienti[i].getCNP()==cnp:
                del self.__clienti[i]
                return
        raise RepositoryExceptie()
        
    def modifica_client_id(self,idcl_vechi,idcl_modif):
        for i in range(len(self.__clienti)):
            if self.__clienti[i].getIdcl() == idcl_vechi:
                self.__clienti[i].set_idcl(idcl_modif)
                return
        raise RepositoryExceptie()
        
    def modifica_client_nume(self,nume_vechi,nume_modif):
        for i in range(len(self.__clienti)):
            if self.__clienti[i].getNume() == nume_vechi:
                self.__clienti[i].set_nume(nume_modif)
                return
        raise RepositoryExceptie()
        
    def cautare_client_cnp(self,cnp_client):
        for i in range(len(self.__clienti)):
            if self.__clienti[i].getCNP() == cnp_client:
                print(self.__clienti[i].getIdcl()+"   "+self.__clienti[i].getNume()+"   "+self.__clienti[i].getCNP())
                return
        raise RepositoryExceptie()   
    
class InMemoryRepositoryInchiriere:
    def __init__(self):
        self.__inchirieri= []
    
    def store(self,inchiriere):
        if inchiriere in self.__inchirieri:
            raise RepositoryExceptie("mesaj")
        self.__inchirieri.append(inchiriere)
        
    def size(self):
        return len(self.__inchirieri)
        
    def getAllInchirieri(self):
        return self.__inchirieri[:]
    
    def sterge_inchiriere_id(self,id_inch):
        for i in range(len(self.__inchirieri)):
            if self.__inchirieri[i].get_id_inch()==id_inch:
                del self.__inchirieri[i]
                return
        raise RepositoryExceptie()
    
    def view_top_inchirieri(self):
        li = []
        for inchiriere in self.__inchirieri:
            li.append(inchiriere.get_carte().getTitlu())
            sub_li = [(el,li.count(el)) for el in set(li)]
        top_inchirieri = self.Sort(sub_li)
        print(top_inchirieri)
        return self.Sort(sub_li)
    
    def view_top_clienti(self):
        li = []
        for inchiriere in self.__inchirieri:
            li.append(inchiriere.get_client().getNume())
            sub_li = [(el,li.count(el)) for el in set(li)]
        self.Sort(sub_li)
        print(self.Sort(sub_li))
        return self.Sort(sub_li)
    
    def view_top_20_clienti(self):
        li = []
        for inchiriere in self.__inchirieri:
            li.append(inchiriere.get_client().getNume())
            sub_li = [(el,li.count(el)) for el in set(li)]
        sortare = self.Sort(sub_li)
        procentaj = int(80/100*len(sub_li))
        while procentaj>0:
            sortare.pop()        
            procentaj -= 1
        print(sortare)
        return sortare
    
    def view_top_autori(self):
        li = []
        for inchiriere in self.__inchirieri:
            li.append(inchiriere.get_carte().getAutor())
            sub_li = [(el,li.count(el)) for el in set(li)]
        self.Sort(sub_li)
        print(self.Sort(sub_li))
        return self.Sort(sub_li)
        
                      
    def Sort(self,sub_li):
        return(sorted(sub_li, key = lambda x: x[1], reverse = True))          
    
def testSort():
    sub_li = [(1,5),(2,7)]
    repinch = InMemoryRepositoryInchiriere() 
    assert repinch.Sort(sub_li) == [(2,7),(1,5)]
        
testSort()

def testStoreClient():
    cl = Client("1","Ana","cnp1")
    rep = InMemoryRepositoryClient()
    assert rep.size() == 0
    rep.storeClient(cl)
    assert rep.size() == 1
    cl2 = Client("2","Vasile","cnp2")
    rep.storeClient(cl2)
    assert rep.size() == 2
    cl3 = Client("3","Maria","cnp2")
    try:
        rep.storeClient(cl3)
        assert False
    except RepositoryExceptie:
        pass

testStoreClient()
    
def testStoreCarti():
    ct = Carte("1", "Harap-Alb", "Rau vs Bine", "Ion Creanga")
    rep = InMemoryRepository()
    assert rep.size() == 0
    rep.store(ct)
    assert rep.size() == 1
    ct2 = Carte("2", "Ion", "Pamant", "Liviu Rebreanu")
    rep.store(ct2)
    assert rep.size() == 2
    ct3 = Carte("2", "Enigma Otiliei", "Otilia", "George Calinescu")
    try:
        rep.store(ct3)
        assert False
    except RepositoryExceptie:
        pass
      
testStoreCarti()

def testStoreInchirieri():
    inchiriere = Inchiriere("1","Ion","Andra")
    repinch = InMemoryRepositoryInchiriere()
    assert repinch.size() == 0
    repinch.store(inchiriere)
    assert repinch.size() == 1
    inchiriere2 = Inchiriere("2","Iona","Andra")
    repinch.store(inchiriere2)
    assert repinch.size() == 2
    inchiriere3 = Inchiriere("2","Ionel","Andra")
    try:
        repinch.store(inchiriere3)
        assert False
    except RepositoryExceptie:
        pass
    
testStoreInchirieri()


def testRepoCarti():
    rep = InMemoryRepository()   
    assert (rep.size() == 0)
    ct = Carte("1","Titlu","Desc","Autor")
    rep.store(ct)
    assert (rep.size() == 1)
    rep.modifica_carte_autor("Autor", "Autor Nou")
    assert (ct == Carte("1","Titlu","Desc","Autor Nou"))
    rep.modifica_carte_descriere("Desc", "Descriere Noua")
    assert (ct == Carte("1","Titlu","Descriere Noua","Autor Nou"))
    rep.modifica_carte_titlu("Titlu", "Titlu nou")
    assert (ct == Carte("1","Titlu Nou","Descriere Noua","Autor Nou"))
    try:
        rep.modifica_carte_autor("a","b")
        assert (False)
    except RepositoryExceptie: 
            pass
    try:
        rep.modifica_carte_descriere("a","b")
        assert (False)
    except RepositoryExceptie: 
            pass
    try:
        rep.modifica_carte_titlu("a","b")
        assert (False)
    except RepositoryExceptie: 
            pass
    try:
        rep.sterge_carte_id("2")
        assert (False)
    except RepositoryExceptie: 
            pass
    rep.sterge_carte_id("1")
    assert rep.size() == 0
    

testRepoCarti()

def testRepoClienti():
    repcl = InMemoryRepositoryClient()
    assert (repcl.size() == 0)
    cl = Client("1","Nume","cnp")
    repcl.storeClient(cl)
    assert(repcl.size() == 1)
    repcl.modifica_client_id("1", "2")
    assert(cl == Client("2","Nume","cnp"))
    repcl.modifica_client_nume("Nume", "Nume nou")
    assert(cl == Client("2","Nume nou","cnp"))
    try:
        repcl.modifica_client_id("a","b")
        assert (False)
    except RepositoryExceptie: 
            pass
    try:
        repcl.modifica_client_nume("a","b")
        assert (False)
    except RepositoryExceptie: 
            pass
    try:
        repcl.stergere_client_cnp("cnp2")
        assert (False)
    except RepositoryExceptie: 
            pass
    repcl.stergere_client_cnp("cnp")
    assert repcl.size() == 0
        
testRepoClienti()
        
def testRepoInchirieri():
    repinch = InMemoryRepositoryInchiriere()
    assert (repinch.size() == 0)
    inchiriere = Inchiriere("1","1","1")
    repinch.store(inchiriere)
    assert(repinch.size() == 1)
    try:
        repinch.sterge_inchiriere_id("2")
        assert (False)
    except RepositoryExceptie: 
        pass
    repinch.sterge_inchiriere_id("1")
    assert(repinch.size() == 0)
    
    
testRepoInchirieri() 