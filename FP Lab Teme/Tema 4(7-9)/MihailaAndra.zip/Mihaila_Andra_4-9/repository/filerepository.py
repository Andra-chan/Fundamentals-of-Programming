from repository.inmemory import InMemoryRepository,InMemoryRepositoryClient,InMemoryRepositoryInchiriere
from domain.entities import Carte,Client,Inchiriere
from utils.fileutils import clearFileContent

class CarteRepositoryFile(InMemoryRepository):
    """
    Responsabil cu stocarea studentilor de la/intr-un text file
    Include diferite versiuni ale:
    - citirii din fisier
    - accesarea atributelor claselor de baza(fields/methods)
    """
    def __init__(self,fileName):
        InMemoryRepository.__init__(self)
        self.__fileName = fileName
        #downloadeaza cartile din file
        self.__loadFromFile2()
        
    def __creeazaCarteDinFile(self,line):
        """
        Proceseaza linia a din file si creeaza o Carte
        returneaza carte
        """
        fields = line.split(" ")
        ct = Carte(fields[0],fields[1],fields[2],fields[3])
        return ct
    
    def __loadFromFile(self):
        """
        Downloadeaza cartile din file
        Downloadeaza file
        """
        fh = open(self.__fileName)
        #citeste intregul file
        content = fh.read()
        fh.close()
        lines = content.split('\n')
        for line in lines:
            if line.strip()=="":
                continue#daca linia e goala, da skip
            ct = self.__creeazaCarteDinFile(line)
            #avem acces la fields din clasa de baza
            self.__carti[ct.getId()] = ct
    
    def __loadFromFile2(self):
        """
        Downloadeaza __carti din file
        proceseaza file linie cu linie
        """
        fh = open(self.__fileName)
        for line in fh:
            if line.strip()=="":
                continue#daca linia e goala, da skip
            ct = self.__creeazaCarteDinFile(line)
            #invoca elementul de stochare din clasa de baza
            InMemoryRepository.store(self, ct)
        fh.close()
        
    def store(self,ct):
        #invoca elementul de stochare din clasa de baza
        InMemoryRepository.store(self, ct)
        self.__appendToFile(ct)
        
    def __appendToFile(self,ct):
        """Adauga o noua linie in file repezentand cartea ct
        """
        fh = open(self.__fileName,"a")
        line = ct.getId()+" "+ct.getTitlu()+" "+ct.getDescriere()+" "+ct.getAutor()
        fh.write(line+"\n")
        fh.close()
        
class ClientRepositoryFile(InMemoryRepositoryClient):
    """
    Responsabil cu stocarea clientilor de la/intr-un text file
    Include diferite versiuni ale:
    - citirii din fisier
    - accesarea atributelor claselor de baza(fields/methods)
    """
    def __init__(self,fileName):
        InMemoryRepositoryClient.__init__(self)
        self.__fileName = fileName
        #downloadeaza cartile din file
        self.__loadFromFileClient2()
        
    def __creeazaClientDinFile(self,line):
        """
        Proceseaza linia a din file si creeaza o Carte
        returneaza carte
        """
        fields = line.split(" ")
        cl = Client(fields[0],fields[1],fields[2])
        return cl
    
    def __loadFromFileClient(self):
        """
        Downloadeaza cartile din file
        Downloadeaza file
        """
        fh = open(self.__fileName)
        #citeste intregul file
        content = fh.read()
        fh.close()
        lines = content.split('\n')
        for line in lines:
            if line.strip()=="":
                continue#daca linia e goala, da skip
            cl = self.__creeazaClientDinFile(line)
            #avem acces la fields din clasa de baza
            self.__client[cl.getIdcl()] = cl
    
    def __loadFromFileClient2(self):
        """
        Downloadeaza __carti din file
        proceseaza file linie cu linie
        """
        fh = open(self.__fileName)
        for line in fh:
            if line.strip()=="":
                continue#daca linia e goala, da skip
            cl = self.__creeazaClientDinFile(line)
            #invoca elementul de stochare din clasa de baza
            InMemoryRepositoryClient.storeClient(self, cl)
        fh.close()
    
    def storeClient(self,cl):
        #invoca elementul de stochare din clasa de baza
        InMemoryRepositoryClient.storeClient(self, cl)
        self.__appendToFileClient(cl)
        
    def __appendToFileClient(self,cl):
        """Adauga o noua linie in file repezentand cartea ct
        """
        fh = open(self.__fileName,"a")
        line = cl.getIdcl()+" "+cl.getNume()+" "+cl.getCNP()
        fh.write(line+"\n")
        fh.close()            
        
def testRepo():
    fileName = "test.txt"
    #ne asiguram ca initializam un file gol
    clearFileContent(fileName)
    repo = CarteRepositoryFile(fileName)
    assert repo.size() == 0
    
def testRead():
    fileName = "c:/temp/test"
    #ne asiguram ca initializam un file gol
    clearFileContent(fileName)
    
    repo = CarteRepositoryFile(fileName)
    repo.store(Carte("9","Carte1","Descriere1","Autor1"))
    repo.store(Carte("10","Carte2","Descriere2","Autor2"))
    
    repo2 = CarteRepositoryFile(fileName)
    assert repo2.size()==2
    
testRepo()
testRead()

class InchiriereRepositoryFile(InMemoryRepositoryInchiriere):
    """
    Responsabil cu stocarea inchirierilor de la/intr-un text file
    Include diferite versiuni ale:
    - citirii din fisier
    - accesarea atributelor claselor de baza(fields/methods)
    """
    def __init__(self,fileName):
        InMemoryRepositoryInchiriere.__init__(self)
        self.__fileName = fileName
        #downloadeaza cartile din file
        self.__loadFromFile2()
        
    def __creeazaInchiriereDinFile(self,line):
        """
        Proceseaza linia a din file si creeaza o Carte
        returneaza carte
        """
        fields = line.split(" ")
        inchiriere = Inchiriere(fields[0],fields[1],fields[2])
        return inchiriere
    
    def __loadFromFile(self):
        """
        Downloadeaza inchirierile din file
        Downloadeaza file
        """
        fh = open(self.__fileName)
        #citeste intregul file
        content = fh.read()
        fh.close()
        lines = content.split('\n')
        for line in lines:
            if line.strip()=="":
                continue#daca linia e goala, da skip
            inchiriere = self.__creeazaInchiriereDinFile(line)
            #avem acces la fields din clasa de baza
            self.__inchirieri.append(inchiriere)
    
    def __loadFromFile2(self):
        """
        Downloadeaza __inchirieri din file
        proceseaza file linie cu linie
        """
        fh = open(self.__fileName)
        for line in fh:
            if line.strip()=="":
                continue#daca linia e goala, da skip
            inchiriere = self.__creeazaInchiriereDinFile(line)
            #invoca elementul de stochare din clasa de baza
            InMemoryRepositoryInchiriere.store(self, inchiriere)
        fh.close()
        
    def store(self,inchiriere):
        #invoca elementul de stochare din clasa de baza
        InMemoryRepositoryInchiriere.store(self, inchiriere)
        self.__appendToFile(inchiriere)
        
    def __appendToFile(self,inchiriere):
        """Adauga o noua linie in file repezentand inchiriere
        """
        fh = open(self.__fileName,"a")
        line = inchiriere.get_id_inch()+" "+inchiriere.get_carte().getId()+" "+inchiriere.get_client().getIdcl()
        fh.write(line+"\n")
        fh.close()

